package com.rest;
import java.util.List;
public interface IProductService 
{
List<Product> findAll();

Product getById(int id);

void addProduct(Product p);


}
