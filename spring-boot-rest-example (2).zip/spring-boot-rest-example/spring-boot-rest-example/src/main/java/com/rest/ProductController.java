package com.rest;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Produces;
import javax.ws.rs.core.Response.Status;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class ProductController 
{
	
	ArrayList<Product> products = new ArrayList<Product>();
@Autowired
private IProductService productService;
//mapping the getProduct() method to /product

@GetMapping("/hello")
public ResponseEntity<String> sayHello() {
	 String msg="welcome to spring rest";
	 HttpHeaders header=new HttpHeaders();
	 //HttpHeaders header1=new HttpHeaders();
	 header.add("desc", "online product seling");
	// header1.add("info", "this is my custom header");
	 return new ResponseEntity<String>(msg,header,HttpStatus.OK);
}

@GetMapping(path="/product", produces={"application/xml"})	
public ResponseEntity<List<Product>>getProduct() 
{
//finds all the products
List<Product> products = productService.findAll();
//returns the product list
return ResponseEntity.ok(products);
}

/*
@GetMapping(path="/product/{id}", produces={"application/xml"})
public ResponseEntity<Object> getProductById(@PathVariable("id") int id) {
	return new ResponseEntity<>(productService.getProductById(id), HttpStatus.OK);	
}*/

@GetMapping(path="/product/{id}", produces={"application/xml"})
public ResponseEntity<Product>getProductById(@PathVariable("id") int id) {
	Product p= productService.getById(id);
	HttpHeaders header=new HttpHeaders();
	header.add("desc","fetching the products by id");
	return  ResponseEntity.ok(p);
	
} 

@PostMapping("/product-add")
public String addProduct(@RequestBody Product p1) {
	
	productService.addProduct(p1);
	return "added";
	
}
@RequestMapping(value = "/products/{id}", method = RequestMethod.DELETE)
public ResponseEntity<Object> delete(@PathVariable("id") String id) { 
   products.remove(id);
   return new ResponseEntity<>("Product is deleted successsfully", HttpStatus.OK);
}

}
