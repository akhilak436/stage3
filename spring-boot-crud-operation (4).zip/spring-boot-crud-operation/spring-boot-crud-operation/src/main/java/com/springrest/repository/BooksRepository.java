package com.springrest.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.springrest.model.Books;
public interface BooksRepository extends JpaRepository<Books, Integer>
{
	//List<Books>findByName(String bookname);
	
	//@Query("select b from Books b where b.bookname = ?1")
    //Books findByBookName(String bookname);

  // @Query("select u from Books u where u.bookname like %?1")
   // List < Books > findByBooknameEndsWith(String bookname);
	
	 // @Query(value = "select * from users where first_name like %?1", nativeQuery = true)
	   // List < User > findByFirstnameEndsWith(String firstname);

	   // @Query(value = "SELECT * FROM USERS WHERE EMAIL_ADDRESS = ?1", nativeQuery = true)
	   // User findByEmailAddress(String emailAddress);
}
