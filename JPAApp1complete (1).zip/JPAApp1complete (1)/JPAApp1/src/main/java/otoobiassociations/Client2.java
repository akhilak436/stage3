package otoobiassociations;



import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client2 {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("abc");
		EntityManager em = factory.createEntityManager();
	/*	em.getTransaction().begin();
		Student2 student = new Student2();
		student.setName("Deepak Patil");
		Address2 homeAddress = new Address2();
		homeAddress.setStreet("MG Road");
		homeAddress.setCity("Pune");
		homeAddress.setState("Maharashtra");
		homeAddress.setZipCode("411 017");
		
		//inject address into student
		student.setAddress(homeAddress);
		
		//persist only student, no need to persist Address explicitly
	//	em.persist(student);
	//	em.getTransaction().commit();
		em.getTransaction().begin();
	*/	
		Student2 student2 = new Student2();
		student2.setName("Babu");
		
		Address2 officeAddress2 = new Address2();
		officeAddress2.setCity("Banglore");
		officeAddress2.setState("Karnataka");
		officeAddress2.setStreet("Hebbal");
		officeAddress2.setZipCode("8786756");
		officeAddress2.setStudent(student2);
		em.getTransaction().begin();
		em.persist(officeAddress2);
		em.flush();
		em.getTransaction().commit();
		
		
		
	
		
		System.out.println("Added one student with address to database.");
		em.close();
		factory.close();
	}
}
