package com.cg.jpacrud.client;


import java.util.List;
import java.util.Scanner;

import com.cg.jpacrud.dao.StudentDao;
import com.cg.jpacrud.dao.StudentDaoImpl;
import com.cg.jpacrud.entities.Student;
import com.cg.jpacrud.service.StudentService;
import com.cg.jpacrud.service.StudentServiceImpl;

public class Client {

	public static void main(String[] args) {
		StudentService service = new StudentServiceImpl();

		//Debug this program as Debug -> Debug as Java Application
        System.out.println("jps with postgres");
		//StudentService service = new StudentServiceImpl();
//
	Student student = new Student(); //model vo
//		student.setStudentId(105);
//		student.setName("ragavi");
//		service.addStudent(student);

		//at this breakpoint, we have added one record to table
//
		student = service.findStudentById(102);
	System.out.print("ID:"+student.getStudentId());
	System.out.println(" Name:"+student.getName());
	
	
		

		student.setName("Sachin Kumar");//object 
		service.updateStudent(student);
		service.removeStudent(student);
		
//		
	//Student s=new Student();
//		s.setStudentId(202);
//		s.setName("akhila1");
//		service.addStudent(s);
	
		
		System.out.println(" list from table ");
		List<Student> list=service.findAllStudents();
		
		for( Student s1:list) {
			System.out.println(s1.getStudentId()+"  "+s1.getName());
		}
      
	/* dynamic query
	 * 
		Scanner sc=new Scanner(System.in);
		System.out.println("enter student id");
		int id=sc.nextInt();sc.nextLine();
		System.out.println("enter student name");
		String name=sc.nextLine();
		StudentDao dao1=new StudentDaoImpl();
		Student ss=dao1.getStudentByIdDynamic(id,name);
		System.out.println(ss);
		
		*/

	}
}
