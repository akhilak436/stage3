package com.cg.jpacrud.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.jpacrud.dao.StudentDao;
import com.cg.jpacrud.dao.StudentDaoImpl;
import com.cg.jpacrud.entities.Student;

public class StudentServiceImpl implements StudentService {

	private StudentDao dao=new StudentDaoImpl();
	

	//@Override
	public void addStudent(Student student) {

		dao.addStudent(student);

	}

	//@Override
	public void updateStudent(Student student) {

		dao.updateStudent(student);

	}

	//@Override
	public void removeStudent(Student student) {
  System.out.println("in service...");
		dao.removeStudent(student);

	}

	//@Override
	public Student findStudentById(int id) {
		//no need of transaction, as it's an read operation
		Student student  = dao.getStudentById(id);
		return student;
	}
	
	
	public List<Student> findAllStudents(){
		List<Student> list= dao.getAll();   //new ArrayList<Student>();
		
		
		return list;
	}
}
