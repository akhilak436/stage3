package com.cg.jpacrud.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.Transaction;


public class JPAUtil {
	static EntityManagerFactory entityManagerFactory;
	static EntityManager entityManager;
	public static  EntityManager getEntityManager() {
		 entityManagerFactory= Persistence.createEntityManagerFactory("abc");
		 entityManager =entityManagerFactory.createEntityManager();
	     return entityManager;
	}
	
	/*public static Transaction   getTransaction() {
		 
		
		return (Transaction)entityManager.getTransaction();
	}*/
	
}
