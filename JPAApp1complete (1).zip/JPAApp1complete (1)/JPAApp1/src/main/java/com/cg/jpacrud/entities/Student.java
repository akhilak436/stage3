package com.cg.jpacrud.entities;



import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;  //JPA
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="studentcg2021")
@NamedQueries({
@NamedQuery(name = "getAllStudents", query = "SELECT s FROM Student s"),
@NamedQuery(name = "getStudentById ", query = "SELECT s FROM Student s where s.studentId=:id")

}
)

public class Student {
	
	private static final long serialVersionUID = 1L;
	@Id
	private Integer studentId;
	
	private String name;
	
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + "]";
	}
	
}
