package com.cg.jpacrud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.jpacrud.client.JPAUtil;
import com.cg.jpacrud.entities.Student;

public class StudentDaoImpl implements StudentDao {
	private EntityManager entityManager;
	//@Override
	public Student getStudentById(int id) {   //not tx
		entityManager=JPAUtil.getEntityManager();
		Student entity = entityManager.find(Student.class, id);//select * from studentcg2021 where id=id
		Student student = new Student();
		student.setName(entity.getName());
		student.setStudentId(entity.getStudentId());//update 
		return student;
	}
//@Override
	public void addStudent(Student student) {  //transcent
	//	try {
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			//JPAUtil.getTransaction().begin();
			entityManager.persist(student); //insert into table values.... //persistent
			entityManager.flush();
			System.out.println("inserted...");
			entityManager.getTransaction().commit();
		/*} catch (Exception e) {
			// TODO Auto-generated catch block
			//entityManager.getTransaction().rollback();
			e.printStackTrace();
		}*/
		/*finally {
			entityManager.close();
		}*/
	}

	//@Override
	public void removeStudent(Student student) {
		entityManager=JPAUtil.getEntityManager();
		Student entity = entityManager.find(Student.class, student.getStudentId());
		entityManager.getTransaction().begin();
		if(entity!=null)		
			entityManager.remove(entity);// delete from table name where id=id;
		entityManager.getTransaction().commit();
	}

	//@Override
	public void updateStudent(Student student) {
		entityManager=JPAUtil.getEntityManager();
		Student entity = entityManager.find(Student.class, student.getStudentId());
		
		if(entity!=null) {
			entityManager.getTransaction().begin();
			entity.setName(student.getName());
			
			entityManager.getTransaction().commit();
		}
	}
	public List<Student> getAll(){
		entityManager=JPAUtil.getEntityManager(); //not transactional
		
	//	Query q=entityManager.createNativeQuery("select * from studentcg2021", Student.class);
		
	//	Query q=entityManager.createQuery("select s from Student s"); //not SQL ,JPQL
		
		Query q=entityManager.createNamedQuery("getAllStudents");
	//	TypedQuery<Student> q=entityManager.createQuery("select s from Student s",Student.class); //not SQL ,JPQL
		List<Student> list=q.getResultList();
		return list;
	}
	
	public Student getStudentByName(){
		entityManager=JPAUtil.getEntityManager(); //not transactional
		//Query q=entityManager.createQuery("select s from Student s where studentId=200"); //not SQL ,JPQL
	//	Student s=(Student)q.getSingleResult();
	
		TypedQuery<Student> q=entityManager.createQuery("select s from Student s where studentId=200",Student.class); //not SQL ,JPQL
		Student s=q.getSingleResult();
		return s;
	}
	public Student getStudentByIdDynamic(int id,String name){
		entityManager=JPAUtil.getEntityManager(); //not transactional
		//Query q=entityManager.createQuery("select s from Student s where studentId=200"); //not SQL ,JPQL
	//	Student s=(Student)q.getSingleResult();
	
	//	TypedQuery<Student> q=entityManager.createQuery("select s from Student s where studentId=:id",Student.class); //not SQL ,JPQL
	//	q.setParameter("id",id);
		
		
		TypedQuery<Student> q=entityManager.createQuery("select s from Student s where studentId=? and name=?",Student.class); //not SQL ,JPQL
		q.setParameter(1,id);
		q.setParameter(2,name);
		
		Student s=q.getSingleResult();
		return s;
	}
	
}
