package onetomanyuni;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("abc");
		EntityManager em = factory.createEntityManager();
	
	
		SideDish dish1 = new SideDish();
		dish1.setSideDishId(1001);
		dish1.setSidedishName("chiken65");
		
		SideDish dish2 = new SideDish();
		dish2.setSideDishId(1002);
		dish2.setSidedishName("Omlet");
		
		SideDish dish3 = new SideDish();
		dish3.setSideDishId(1003);
		dish3.setSidedishName("Applo fish");
		
		Set<SideDish> mydishes= new HashSet<SideDish>();
		mydishes.add(dish1);
		mydishes.add(dish2);
		mydishes.add(dish3);
		
		Beer beer= new Beer();
		beer.setBeerId(1);
		beer.setBeerName("Budwiser");
		beer.setDishes(mydishes);
		
		em.getTransaction().begin();
		
			
			em.persist(beer);
			em.getTransaction().commit();
			System.out.println("Data inserted successfully");
	
	}

}
