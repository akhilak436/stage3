package com.examples.mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;


public class HibernateTest {

	public static void main(String[] args) {
		 SessionFactory sessionFactory = HibernateUtil.getSessionFactory(); 
		 Session session = sessionFactory.openSession();
		 session.beginTransaction();  
		 
		 Author author = new Author();
		 author.setId(10);
		 author.setName("O. Henry");
		 
		 Biography biography = new Biography();
		
		 biography.setAuthorId(1);
		 biography.setInformation("William Sydney Porter  better known as O. Henry...");
		 
		 author.setBiography(biography);
		 biography.setAuthor(author);
		 
		 session.save(author);  
         
	     session.getTransaction().commit();  
	          
	     session.close();  
		 

	}

}
