package com.example.many;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;



public class Many_TMany_Test_Unidirection {

	public static void main(String[] args) {
		
		Session session=HibernateUtil.getSessionFactory().openSession();
		
		Scholar scholar1 = new Scholar();
		scholar1.setScholarId(1002);
		scholar1.setScholarName("Pushpalatha");
		
		Scholar scholar2 = new Scholar();
		scholar2.setScholarId(1003);
		scholar2.setScholarName("Jayanthi");
		
		Scholar scholar3 = new Scholar();
		scholar3.setScholarId(1004);
		scholar3.setScholarName("Rama");
		
		Set<Scholar> scholarlist= new HashSet<Scholar>();
		scholarlist.add(scholar1);
		scholarlist.add(scholar2);
		scholarlist.add(scholar3);
		
		
		Trainer trainer1 = new Trainer();
		trainer1.setTrainerId(5);
		trainer1.setTrainerName("ram");
		trainer1.setScholars(scholarlist);
		
		Trainer trainer2 = new Trainer();
		trainer2.setTrainerId(6);
		trainer2.setTrainerName("petter");
		trainer2.setScholars(scholarlist);
		
		Trainer trainer3 = new Trainer();
		trainer3.setTrainerId(7);
		trainer3.setTrainerName("laxman");
		trainer3.setScholars(scholarlist);
		
		session.beginTransaction();
		try{
			
			session.save(trainer1);
			session.save(trainer2);
			session.save(trainer3);
			
			session.getTransaction().commit();
			System.out.println("Data inserted successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		

	}

}
