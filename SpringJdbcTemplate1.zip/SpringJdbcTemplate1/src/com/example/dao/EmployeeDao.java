package com.example.dao;

import com.example.model.Employee;

public interface EmployeeDao {
	public int saveEmployee(Employee e);
	public int updateEmployee(Employee e);
	public int deleteEmployee(Employee e);
	

}
