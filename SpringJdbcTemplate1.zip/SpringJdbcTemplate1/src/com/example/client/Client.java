package com.example.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.dao.EmployeeDao;
import com.example.dao.EmployeeDaoImpl;
import com.example.model.Employee;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ctx=new ClassPathXmlApplicationContext("Beans.xml");
		EmployeeDaoImpl d=(EmployeeDaoImpl) ctx.getBean("edao");
		//int status=d.saveEmployee(new Employee(40,"jack",45000));
		//int status=d.updateEmployee(new Employee(40,"john",15000)); 
	   // System.out.println(status);
		
List<Employee> list=d.getAllEmployees();  
        
	    for(Employee e:list)  
	        System.out.println(e); 
	    
List<Employee> list1=d.getAllEmployeesRowMapper();  
        
	    for(Employee e:list1)  
	        System.out.println(e); 
	    
	   // boolean b=d.saveEmployeeByPreparedStatement(new Employee(20,"raj",50000));
	    //System.out.println("employee created successfully");
	    /*
		Employee e=new Employee(); 
	    e.setId(102); 
	    int status=d.deleteEmployee(e); 
		System.out.println(status);*/
		((AbstractApplicationContext) ctx).close();
		
		
	}

}
