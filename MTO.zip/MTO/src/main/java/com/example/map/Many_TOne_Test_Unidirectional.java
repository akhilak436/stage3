package com.example.map;

import org.hibernate.HibernateException;
import org.hibernate.Session;



public class Many_TOne_Test_Unidirectional {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Module module = new Module();
		module.setModuleId(1003);
		module.setModuleName("Java");
		
		Student student1 = new Student();
		student1.setStudentId(6);
		student1.setStudentName("karhik");
		student1.setModule(module);
		
		Student student2 = new Student();
		student2.setStudentId(7);
		student2.setStudentName("archana");
		student2.setModule(module);
		
		session.beginTransaction();
		try{
			session.save(student1);
			session.save(student2);
			
			session.getTransaction().commit();
			System.out.println("Data inserted Successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}finally {
			if(session!=null){
				session.close();
			}
		}
		

	}

}
