package com.stage3.hibernate.HibernateProject;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SessionFactory factory = HibernateUtil.getSessionFactory(); 
    	Session session = factory.openSession();  
    	Transaction t = session.beginTransaction();  
    	/*
    	Student s=new Student(4,"neha",70);
    	session.save(s);
    	
    	Student s2=new Student(2,"abhishek",75);
    	Student s3=new Student(3,"Ragavi",76);
    	
    	session.save(s2);
    	session.save(s3);
        
    	System.out.println("records are inserted successfully");
    	Student s1=session.get(Student.class, 1);
     System.out.println(s1);
     
     */
    	
    	//hQl queries
    	
    	Query q=session.createQuery("from Student");
    	List<Student>st=q.getResultList();
    	System.out.println(st);
    	
    	//pagination 
    	
    	Query q1=session.createQuery("from Student");
    	
    	q1.setFirstResult(1);
    	q1.setMaxResults(3);
    	List<Student>st1=q1.getResultList();
    	System.out.println(st1);
    	/*
    	//Hql update query
    	String hql="update Student set name=:n where id=:i";
    	Query q2=session.createQuery(hql);
    	q2.setParameter("n", "abhi");
    	q2.setParameter("i", 2);
    	int i=q2.executeUpdate();
    	System.out.println("updated successfully"+i);
    	
    	Student s1=session.get(Student.class, 2);
        System.out.println(s1);
    	
      //Hql delete query
    	String hql1="delete from Student where id=3";
    	Query q3=session.createQuery(hql1);
    	
    	q3.executeUpdate();
    	System.out.println("deleted successfully"); 
    	
    	*/
    	
    	//HQL aggregate functions
     //max,min,avg,count,sum
    	Query q4=session.createQuery("select count(marks) from Student");
    	List<Student>st3=q4.list();
    	System.out.println(st3);
    	
     
    	t.commit();
    	
    	session.close();
    	factory.close();
	}

}
